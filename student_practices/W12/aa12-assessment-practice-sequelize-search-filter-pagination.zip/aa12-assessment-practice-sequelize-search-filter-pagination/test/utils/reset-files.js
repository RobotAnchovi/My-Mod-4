const { resetFiles } = require('./test-utils');

resetFiles();
