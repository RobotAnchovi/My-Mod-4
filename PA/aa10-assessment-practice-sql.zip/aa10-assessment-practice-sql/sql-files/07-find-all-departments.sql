-- Your code here
SELECT DISTINCT department FROM tools WHERE department IS NOT NULL ORDER BY department;
