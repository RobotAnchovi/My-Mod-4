-- Your code here
SELECT first_name, last_name
FROM customers
ORDER BY last_name, first_name;
