-- Your code here
UPDATE tools SET department = NULL WHERE department = 'Plumbing';
