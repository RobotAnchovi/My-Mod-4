-- Your code here
SELECT name, price
FROM tools
WHERE price BETWEEN 14.67 AND 20.09
ORDER BY name;
